package multinotepad.iit.com.mulinotepad.utility;

public interface OnItemClick {
    void onItemLongClick(Object obj);

    void onItemClick(Object obj);
}
