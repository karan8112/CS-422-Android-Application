package multinotepad.iit.com.mulinotepad.utility;

public interface OnClickListener {
    void OnPositiveButtonClick();

    void OnNegativeButtonClick();
}
