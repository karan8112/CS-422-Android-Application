package stockwatch.iit.com.stockwatch.activities;

import android.os.AsyncTask;

import org.json.JSONObject;
import android.widget.Toast;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;

import stockwatch.iit.com.stockwatch.activities.AsyncTaskSymbolCompany;
import stockwatch.iit.com.stockwatch.models.stockmodel;

public class AsyncTaskStockData extends AsyncTask<String, Void, String> {

    private MainActivity callbackContext;
    private String StockSymbol;
    private stockmodel stockData;
    private String CompanyName;
    private double StockPrice;
    private double StockPriceChange;
    private double percentagechange;
    AsyncTaskSymbolCompany a = new AsyncTaskSymbolCompany();
    private static final String TAG = "Async2";



    public static final String Symbol_URL = "https://api.iextrading.com/1.0/stock/";


    public AsyncTaskStockData(MainActivity context){
        callbackContext = context;
    }

    protected void onPreExecute() {
        super.onPreExecute();
    }

    protected void onPostExecute(String s){
        Log.d(TAG,"Data iN postexecute"+ s);
        stockmodel sd = parse(s);
        callbackContext.stockUpdate(sd);
    }

    @Override
    protected String doInBackground(String... strings) {
        String symbol =  strings[0];
        Log.d(TAG,"Symbol data to found"+symbol);
        String url = Symbol_URL + symbol + "/quote?displayPercent=true";
        String s = a.connectToUrl(url);
        return s;
    }

    private stockmodel parse(String s) {
        try {
            stockData = new stockmodel();
            JSONObject jObjMain = new JSONObject(s);
            stockData.setStockSymbol(jObjMain.getString("symbol"));
            stockData.setCompanyName(jObjMain.getString("companyName"));
            stockData.setStockPrice(jObjMain.getDouble("latestPrice"));
            stockData.setStockPriceChange(jObjMain.getDouble("change"));
            stockData.setPercentagechange(jObjMain.getDouble("changePercent"));
            return stockData;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
