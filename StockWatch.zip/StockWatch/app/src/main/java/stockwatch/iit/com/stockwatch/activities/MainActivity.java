package stockwatch.iit.com.stockwatch.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import stockwatch.iit.com.stockwatch.R;
import stockwatch.iit.com.stockwatch.adapter.StockWatchAdapter;
import stockwatch.iit.com.stockwatch.models.stockmodel;
import stockwatch.iit.com.stockwatch.utility.CommonFunction;
import stockwatch.iit.com.stockwatch.utility.OnClickListener;

public class MainActivity extends AppCompatActivity implements View.OnLongClickListener, View.OnClickListener{
    private RecyclerView recyclerView;
    private static final String TAG = "MainActivity";
    private final static String marketWatchURL = "http://www.marketwatch.com/investing/stock";
    private StockWatchAdapter adapter;
    private DatabaseHandler databaseHandler;
    public String stock_symbol;
    private SwipeRefreshLayout swiper;
    private TextView button;
    private final static List<stockmodel> stocklist = new ArrayList<>();
    //private final static List<stockmodel> stockListtemp = new ArrayList<>();
    private HashMap<String, String> data_after_query = new HashMap<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final View v = null;
        recyclerView = findViewById(R.id.recycler);
        adapter = new StockWatchAdapter(MainActivity.this, stocklist);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        new AsyncTaskSymbolCompany().execute();
        if(checkconnectivity())
        {
            adapter.notifyDataSetChanged();
        }


        DatabaseHandler db = new DatabaseHandler(this);
        stockmodel st = new stockmodel();

//        button = (TextView)findViewById(R.id.StockPrice);
//        button.setOnClickListener(onClick(v));

        swiper = (SwipeRefreshLayout) findViewById(R.id.swiper);

        swiper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                doRefresh();
            }
        });




    }

    protected void onResume() {
//        boolean flag=true;
//        Log.d(TAG, "onResume: ");
//        DatabaseHandler databaseHandler = new DatabaseHandler(MainActivity.this);
//        ArrayList<stockmodel> list = databaseHandler.loadStocks();
//        stocklist.clear();
//        for(int i=0;i<list.size();i++){
//            stockmodel temp= list.get(i);
//            async(temp.getStockSymbol());
//        }
        DatabaseHandler databaseHandler = new DatabaseHandler(MainActivity.this);
        if(databaseHandler.getReadableDatabase()!=null)
        {
            ArrayList<stockmodel> list = databaseHandler.loadStocks();
            if(checkconnectivity())
            {
                stocklist.clear();
                for(int i=0;i<list.size();i++){
                    stockmodel temp= list.get(i);
                    async(temp.getStockSymbol());
                }
            }
            else{
                Log.d(TAG,"on network off------------");
                stocklist.clear();
                for(int i=0;i<list.size();i++){
                    stockmodel temp= list.get(i);
                    String symbol = temp.getStockSymbol();
                    String companyname = temp.getCompanyName();
                    stocklist.add(new stockmodel(symbol, companyname,0,0,0));
                    Collections.sort(stocklist, new comparator());
                    adapter.notifyDataSetChanged();
                }
            }
        }
        super.onResume();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.add_stock) {
            if(checkconnectivity())
            {
                new AsyncTaskSymbolCompany().execute();
                add_stock();
            }
            else
                {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Stocks cannnot be added without a Network Connection");
                builder.setTitle("No Network Connection");
                AlertDialog dialog = builder.create();
                dialog.show();
            }
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //checkconnectivity
    public boolean checkconnectivity(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = connectivityManager.getActiveNetworkInfo();
        if(ni!=null && ni.isConnected())
        {
            return true;
        }
        else{
            Toast.makeText(this, "Internet Not Connected!!!", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    //add_stock
    public void  add_stock(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);;
        et.setFilters(new InputFilter[]{new InputFilter.AllCaps()});
        et.setGravity(Gravity.CENTER_HORIZONTAL);
        builder.setView(et);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                    AsyncTaskSymbolCompany st = new AsyncTaskSymbolCompany();
                    HashMap<String, String> data = st.findstock(et.getText().toString());
                    if(data!=null)
                    {
                        if(data.size()==1)
                        {
                            if(checkDuplicate(data.get(et.getText().toString()))){
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("Stocks symbol "+et.getText().toString()+" is already displayed");
                                builder.setTitle("Duplicate Stock");
                                AlertDialog dialog1 = builder.create();
                                dialog1.show();
                            }
                            else{
                                add_stock_db(et.getText().toString(), data.get(et.getText().toString()));
                            }
                        }
                        else if(data.size()>1)
                        {
                            showListDialog(data);
                        }
                        else{
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setMessage("Data for stock symbol");
                            builder.setTitle("Symbol Not Found: "+et.getText().toString());
                            AlertDialog dialog1 = builder.create();
                            dialog1.show();
                        }
                    }
                    else{
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setMessage("No Stock Symbol Found.");
                        builder.setTitle("No Stock");
                        AlertDialog dialog1 = builder.create();
                        dialog1.show();
                    }

                }
        });
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the dialog
                dialog.cancel();
            }
        });

        builder.setMessage("Please enter a stock symbol:");
        builder.setTitle("Stock Selection");

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //delete on long click
    public void onItemLongClick(Object obj) {
        final stockmodel note = (stockmodel) obj;
        CommonFunction.getInstance().showAlertDialog(MainActivity.this, "Delete Stock '" + note.getStockSymbol() + "' ?", "YES", "NO", new OnClickListener() {
            public void OnPositiveButtonClick() {
                stocklist.remove(note);
                DatabaseHandler dt = new DatabaseHandler(MainActivity.this);
                dt.deleteStock(note.getStockSymbol());
                adapter.notifyDataSetChanged();
            }

            public void OnNegativeButtonClick() {

            }
        });
    }


    //onclick

    public void onClick(View view) {
        //View call = (View) view.getParent().getParent().getParent();
        int pos = recyclerView.getChildLayoutPosition(view);
        stockmodel s = stocklist.get(pos);
        String url1 = marketWatchURL+"/"+s.getStockSymbol();
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url1));
        startActivity(i);
    }


    //stockupdate
    public void stockUpdate(stockmodel data){
        Log.d(TAG,"jhsjhsfjhfhfhsdhfdshfjhsfjdhh"+data);
            if(checkconnectivity())
            {
                Log.d(TAG,"adding to connectivity");
                if(stocklist.contains(data))
                {
                    Toast.makeText(this,"Already",Toast.LENGTH_SHORT).show();
                }
                else{
                    Log.d(TAG,"adding to stocklist");
                    stocklist.add(data);
                    Collections.sort(stocklist, new comparator());
                    Log.d(TAG,"modifying adapter");
                    adapter.notifyDataSetChanged();
                }
            }
    }

    //check duplicate
    public boolean checkDuplicate(String et){
        Log.d(TAG,"Check duplicate "+et);
        stockmodel temp=null;
        Log.d(TAG,"Temp duplicate  "+stocklist.size());
        for(int i=0;i<stocklist.size();i++)
        {
            temp=stocklist.get(i);
            Log.d(TAG,"Temp duplicate  "+temp.getStockSymbol());
            String symbol_name = temp.getStockSymbol();
            if(temp.getStockSymbol()==null)
            {
                Log.d(TAG,"Check duplicate jio--- null--- "+temp.getStockSymbol());
            }
            Log.d(TAG,"Check duplicate jio--- "+temp.getStockSymbol());
            if(temp.getStockSymbol().equals(et.toString()))
            {
                return true;
            }

        }
        return  false;
    }

    //showlistdialog
    public void showListDialog(HashMap<String,String> list) {
        final CharSequence[] sArray = new CharSequence[list.size()];
        Iterator it = list.entrySet().iterator();
        int i=0;
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            sArray[i]=pair.getKey()+"-"+pair.getValue();
            i++;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Make a selection");
        builder.setItems(sArray, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                add_stock_db(sArray[which].toString().split("-")[0], sArray[which].toString().split("-")[1]);
            }
        });
        builder.setNegativeButton("Nevermind", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the dialog
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    //store stock to database
    public void add_stock_db(String symbol, String CompanyName){
        if(checkDuplicate(symbol)){
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setMessage("Stocks symbol "+symbol+" is already displayed");
            builder.setIcon(R.drawable.ic_warning_black_24dp);
            builder.setTitle("Duplicate Stock");
            AlertDialog dialog1 = builder.create();
            dialog1.show();
        }
        else{
            DatabaseHandler dt = new DatabaseHandler(MainActivity.this);
            dt.insertstock(symbol, CompanyName);
            async(symbol);
        }
    }

    //async call
    public void async(String stock_symbol){
        if(checkconnectivity()){
            AsyncTaskStockData st = new AsyncTaskStockData(MainActivity.this);
            st.execute(stock_symbol);

        }
        else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Stocks cannot be added without a network connection");
            builder.setTitle("No Network Connection");
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    public void doRefresh(){
        if(checkconnectivity()) {
            Log.d(TAG,"Refresh Data"+stocklist.size());
            refreshstoredata();
//            List<stockmodel> in = new ArrayList<>();
//            in = stocklist;
//            for (int i = 0; i < in.size(); i++) {
//                String tempVar = in.get(i).getStockSymbol();
//                Log.d(TAG,"Refresh Data111---"+ tempVar);
//                stocklist.remove(stocklist.get(i));
//                Log.d(TAG,"Refresh Data after removal---"+in.size());
//                async(tempVar);
//            }
//            swiper.setRefreshing(false);
        }
        else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Stocks cannot be updated without a network connection");
            builder.setTitle("No Network Connection");
            AlertDialog dialog = builder.create();
            dialog.show();
            swiper.setRefreshing(false);
        }
    }



    protected void onDestroy() {
        DatabaseHandler databaseHandler = new DatabaseHandler(MainActivity.this);
        databaseHandler.shutDown();
        super.onDestroy();
    }



    public boolean onLongClick(View view) {
        Log.d(TAG,"D");
        int pos = recyclerView.getChildLayoutPosition(view);
        final stockmodel stock = stocklist.get(pos);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                stocklist.remove(stock);
                DatabaseHandler databaseHandler = new DatabaseHandler(MainActivity.this);
                databaseHandler.deleteStock(stock.getStockSymbol());
                adapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.setMessage("Delete stock symbol "+stock.getStockSymbol()+" ?");
        builder.setIcon(R.drawable.ic_delete_black_24dp);
        builder.setTitle("Delete Stock");
        AlertDialog dialog = builder.create();
        dialog.show();
        return false;
    }

    //refreshadata function
    public void refreshstoredata(){
        Async3 refresh = new Async3(this);
        if(checkconnectivity()){
            refresh.execute(stocklist);
        }else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Stocks cannot be added without a network connection");
            builder.setTitle("No Network Connection");
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    public void addRefreshData(List<stockmodel> list)
    {
        if(list!=null) {
            stocklist.clear();
            stocklist.addAll(list);
            Collections.sort(stocklist, new comparator());
            adapter.notifyDataSetChanged();
            swiper.setRefreshing(false);
        }
    }


    public void setData(){
        DatabaseHandler databaseHandler = new DatabaseHandler(MainActivity.this);
        ArrayList<stockmodel> list = databaseHandler.loadStocks();
        //stocklist.clear();
        Log.d(TAG,"do reset--------"+list.size());
        for(int i=0;i<list.size();i++){
            stockmodel stockData = new stockmodel();
            stockData.setStockSymbol(String.valueOf(list.get(i).getStockSymbol()));
            stockData.setCompanyName(String.valueOf(list.get(i).getCompanyName()));
            stockData.setStockPrice(0);
            stockData.setStockPriceChange(0);
            stockData.setPercentagechange(0);
            stocklist.add(stockData);
            Collections.sort(stocklist, new comparator());
            Log.d(TAG,"modifying adapter"+stocklist.size());
            adapter.notifyDataSetChanged();
        }
    }




}
