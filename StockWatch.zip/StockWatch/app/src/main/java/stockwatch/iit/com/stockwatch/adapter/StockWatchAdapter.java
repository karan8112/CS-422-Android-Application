package stockwatch.iit.com.stockwatch.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import java.util.List;

import stockwatch.iit.com.stockwatch.R;
import stockwatch.iit.com.stockwatch.activities.MainActivity;
import stockwatch.iit.com.stockwatch.models.stockmodel;

public class StockWatchAdapter extends RecyclerView.Adapter<StockWatchAdapter.ViewHolder> {

    private MainActivity context;
    private MainActivity mainActivity;
    private List<stockmodel> stockList;
    private static final String TAG = "StockAdapter";

    public StockWatchAdapter(MainActivity mainActivity, List<stockmodel> stockList) {
        this.context = mainActivity;
        this.stockList = stockList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.stock_list, viewGroup, false);
        view.setOnClickListener(context);
        view.setOnLongClickListener(context);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        stockmodel st = stockList.get(position);
        viewHolder.stockSymbol.setText(st.getStockSymbol().trim());
        viewHolder.stockcompanyName.setText(st.getCompanyName().trim());
        viewHolder.stockPrice.setText(String.valueOf(st.getStockPrice()));
        double in = st.getPercentagechange();
        String s = String.format("%.2f",in);
        if(st.getStockPriceChange()>=0) {

                String priceChange="▲ "+st.getStockPriceChange()+" ("+s+"%)";
                viewHolder.stockpriceChange.setText(priceChange);
                viewHolder.stockpriceChange.setTextColor(Color.GREEN);
                viewHolder.stockSymbol.setTextColor(Color.GREEN);
                viewHolder.stockPrice.setTextColor(Color.GREEN);
                viewHolder.stockcompanyName.setTextColor(Color.GREEN);
        }
        else {
                String priceChange="▼ "+st.getStockPriceChange()+" ("+s+"%)";
                viewHolder.stockpriceChange.setText(priceChange);
                viewHolder.stockpriceChange.setTextColor(Color.RED);
                viewHolder.stockSymbol.setTextColor(Color.RED);
                viewHolder.stockPrice.setTextColor(Color.RED);
                viewHolder.stockcompanyName.setTextColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return stockList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        public TextView stockSymbol;
        public TextView stockPrice;
        public TextView stockpriceChange;
        public TextView stockcompanyName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            stockSymbol = itemView.findViewById(R.id.StockSymbol);
            stockPrice = itemView.findViewById(R.id.StockPrice);
            stockpriceChange = itemView.findViewById(R.id.StockPriceChange);
            stockcompanyName = itemView.findViewById(R.id.StockCompanyName);
        }
    }
}
