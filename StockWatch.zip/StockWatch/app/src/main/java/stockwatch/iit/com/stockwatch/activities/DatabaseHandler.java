package stockwatch.iit.com.stockwatch.activities;

import android.content.ContentValues;
import android.util.Log;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import stockwatch.iit.com.stockwatch.adapter.StockWatchAdapter;
import stockwatch.iit.com.stockwatch.models.stockmodel;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHandler";
    private static final String DATABASE_NAME = "StockExchange";
    private static final String TABLE_NAME = "StockTable";
    private static final String SYMBOL = "Symbol";
    private static final String COMPANY = "CompanyName";

    private static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    SYMBOL + " TEXT not null unique," +
                    COMPANY + " TEXT not null)";

    private SQLiteDatabase database;

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, 1);
        database = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void deleteStock(String SYMBOL){
        int cnt = database.delete(TABLE_NAME, "Symbol = ?", new String[]{SYMBOL});
    }

    public void insertstock(String symbol, String compnayName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(SYMBOL,symbol);
        cv.put(COMPANY,compnayName);
        db.insert(TABLE_NAME, null, cv);
    }

    public ArrayList<stockmodel> loadStocks() {
        Log.d(TAG,"Take data-------");
        ArrayList<stockmodel> stocks = new ArrayList<>();
        Cursor cursor = database.query(
                TABLE_NAME, // The table to query
                new String[]{SYMBOL, COMPANY}, // The columns to return
                null, // The columns for the WHERE clause
                null, // The values for the WHERE clause
                null, // don't group the rows
                null, // don't filter by row groups
                null); // The sort order
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); i++) {
                String symbol = cursor.getString(0);
                String company = cursor.getString(1);
                stockmodel stock = new stockmodel(symbol, company);
                stocks.add(stock);
                cursor.moveToNext();
            }
            cursor.close();
        }
        Log.d(TAG,"Take data------- +++"+stocks.size());
        return stocks;
    }




    public void shutDown(){
        database.close();
    }
}
