package stockwatch.iit.com.stockwatch.models;

import android.util.Log;

import java.io.Serializable;
import java.util.concurrent.locks.Lock;

public class stockmodel implements Serializable {
    private String StockSymbol;
    private String CompanyName;
    private double StockPrice;
    private double StockPriceChange;
    private double Percentagechange;
    private static final String TAG = "stockmodel";

    public stockmodel(){

    }

    public stockmodel(String stockSymbol, String companyName, double stockPrice, double stockPriceChange, double percentagechange) {
        StockSymbol = stockSymbol;
        CompanyName = companyName;
        StockPrice = stockPrice;
        StockPriceChange = stockPriceChange;
        Percentagechange = percentagechange;
    }

    public stockmodel(String symbol, String companyName) {
        this.StockSymbol = symbol;
        this.CompanyName = companyName;
    }

    public void setStockSymbol(String stockSymbol) {
        this.StockSymbol = stockSymbol;
    }

    public void setCompanyName(String companyName) {
        this.CompanyName = companyName;
    }

    public void setStockPrice(double stockPrice) {
        this.StockPrice = stockPrice;
    }

    public void setStockPriceChange(double stockPriceChange) {
        this.StockPriceChange = stockPriceChange;
    }

    public void setPercentagechange(double percentagechange) {
        this.Percentagechange = percentagechange;
    }





    public String getStockSymbol() {
        return StockSymbol;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public double getStockPrice() {
        return StockPrice;
    }

    public double getStockPriceChange() {
        return StockPriceChange;
    }

    public double getPercentagechange() {
        return Percentagechange;
    }
}
