package stockwatch.iit.com.stockwatch.activities;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import stockwatch.iit.com.stockwatch.activities.AsyncTaskSymbolCompany;
import stockwatch.iit.com.stockwatch.models.stockmodel;

public class Async3 extends AsyncTask<List<stockmodel>, Void, List<stockmodel>>{
    private MainActivity mainActivity;
    private List<stockmodel> stockList;

    public Async3(MainActivity context){
        mainActivity = context;
    }

    public Async3() {

    }

    protected void onPostExecute(List<stockmodel> stockList) {
        mainActivity.addRefreshData(stockList);
    }



    protected List<stockmodel> doInBackground(List<stockmodel>... lists) {
        try {
            List<stockmodel> returnList = new ArrayList<>();
            for(int i=0;i<lists[0].size();i++) {
                String symbol = lists[0].get(i).getStockSymbol();
                Log.d("INFO", "GETTING DATA FOR " + symbol);
                URL url = new URL("https://api.iextrading.com/1.0/stock/" + symbol + "/quote?displayPercent=true");
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line = "";
                String jdata = "";
                while (line != null) {
                    line = bufferedReader.readLine();
                    jdata = jdata + line;
                }
                Log.d("INFO ", "DATA IN ASYNC LOAD " + jdata);
                JSONObject jsonObject = new JSONObject(jdata);
                stockmodel stock = new stockmodel();
                //Set stock symbol
                stock.setStockSymbol(jsonObject.getString("symbol").trim());

                //Set stock companyName
                stock.setCompanyName(jsonObject.getString("companyName").trim());

                //Set latest price
                stock.setStockPrice(jsonObject.getDouble("latestPrice"));

                //Set change
                stock.setStockPriceChange(jsonObject.getDouble("change"));

                //Set change percentage
                stock.setPercentagechange(jsonObject.getDouble("changePercent"));

                returnList.add(stock);
            }
            return  returnList;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }


}
