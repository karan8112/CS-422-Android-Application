package stockwatch.iit.com.stockwatch.activities;

import stockwatch.iit.com.stockwatch.models.stockmodel;
import java.util.Comparator;

public class comparator implements Comparator<stockmodel>{
    public int compare(stockmodel st, stockmodel t1){
        return st.getStockSymbol().compareTo(t1.getStockSymbol());
    }
}
