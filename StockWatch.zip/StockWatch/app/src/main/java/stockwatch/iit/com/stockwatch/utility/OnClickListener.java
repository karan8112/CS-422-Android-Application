package stockwatch.iit.com.stockwatch.utility;

public interface OnClickListener {
    void OnPositiveButtonClick();

    void OnNegativeButtonClick();
}
