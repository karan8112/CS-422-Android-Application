package stockwatch.iit.com.stockwatch.activities;

import android.os.AsyncTask;
import android.net.Uri;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;


public class AsyncTaskSymbolCompany extends AsyncTask<String, Void, String> {
    private static final String TAG = "Async1";
    private static final String Symbol_URL = "https://api.iextrading.com/1.0/ref-data/symbols";
    public static HashMap<String, String> symbol_company = new HashMap<>();
    protected void onPreExecute() {
        super.onPreExecute();
    }

    protected void onPostExecute(String s){
        String s1 = s;
        Log.d(TAG, "ArrayList: " + s1);
        symbol_company = parse(s1);
        //symbol_company = parse(s);

    }

    @Override
    protected String doInBackground(String... strings) {
        String s = connectToUrl(Symbol_URL);
        Log.d(TAG, "back: " + s);
        return s;
    }

    public String connectToUrl(String url1)
    {
        Uri dataUri = Uri.parse(url1);
        String urlforuse = dataUri.toString();
        Log.d(TAG, "doInBackground: " + urlforuse);
        StringBuilder sb = new StringBuilder();
        try{
            URL url = new URL(urlforuse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            InputStream in = conn.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;
            while((line = br.readLine())!= null)
            {
                sb.append(line).append('\n');
            }
        } catch (Exception e){
                e.printStackTrace();
                Log.d(TAG, "Exception doIdksjdfkjsnBackground: " + e.getMessage());
                return null;
        }
        return sb.toString();
    }

    private HashMap<String, String> parse(String s)
    {
        HashMap<String, String> storedata = new HashMap<>();
        try{
            Log.d(TAG, "jsonobject: " + "jshjhdsj");
            JSONArray j_list = new JSONArray(s);
            for(int i=0; i<j_list.length(); i++)
            {
                JSONObject jobj =(JSONObject)j_list.get(i);
                storedata.put(jobj.getString("symbol"), jobj.getString("name"));
            }
            return storedata;
        }catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }

    }

    public HashMap<String, String> findstock(String s){
        HashMap<String, String> storedata = new HashMap<>();
        for(Map.Entry<String,String> entry : symbol_company.entrySet()){
            String symbol = entry.getKey();
            String name = entry.getValue();
            if(symbol.startsWith(s)){
                Log.d(TAG,"Symbol"+symbol);
                storedata.put(symbol,name);
            }
            }
        return  storedata;
    }


}
