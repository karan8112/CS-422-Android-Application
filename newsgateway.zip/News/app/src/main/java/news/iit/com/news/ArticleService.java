package news.iit.com.news;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;

import java.util.ArrayList;

public class ArticleService extends Service {
    private static final String TAG = "ArticleService";
    private boolean isRunning = true;
    private ArrayList<Article> articles_list = new ArrayList <Article>();
    private NewsReceiver newsReceiver;



    public ArticleService(){

    }



    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        newsReceiver = new NewsReceiver();
        IntentFilter filter = new IntentFilter(MainActivity.Get_Source_Data);
        registerReceiver(newsReceiver, filter);
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG,"show list size---------------------------"+articles_list.size());
                while (isRunning) {
                    while(articles_list.isEmpty()){
                        try {
                            Thread.sleep(250);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    Intent intent = new Intent();
                    intent.setAction(MainActivity.Get_Article_Data);
                    intent.putExtra("display_article", articles_list);
                    sendBroadcast(intent);
                    articles_list.clear();
                }
                Log.i(TAG, "NewsService was properly stopped");
            }
        }).start();

        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        super.onDestroy();
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void setArticle(ArrayList<Article> article_list)
    {
        Log.d(TAG,"god ur great-------------");
        articles_list.clear();
        articles_list.addAll(article_list);
    }

    class NewsReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {

                case MainActivity.Get_Source_Data:
                    Log.d(TAG,"hdjhsjdhjsjsd---------------------------");
                    String sourceId ="";
                    String temp="";
                    if (intent.hasExtra("Source_Name")) {
                        sourceId = intent.getStringExtra("Source_Name");
                        temp=sourceId.replaceAll(" ","-");
                    }

                    new NewsArticleAPI(ArticleService.this, temp).execute();
                    break;
            }
        }
    }
}
