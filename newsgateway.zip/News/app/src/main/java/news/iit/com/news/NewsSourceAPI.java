package news.iit.com.news;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class NewsSourceAPI extends AsyncTask<String, Integer, String> {

    private Uri.Builder builder;
    private static final String TAG = "NewsSourceAPI";
    private StringBuilder sb1;
    private boolean noDataFound=false;
    private String newsurl;
    private String category;
    private String API = "94a257111d92411896069c0bc292c8ff";
    private ArrayList<Source> sourceList = new ArrayList <Source>();
    private ArrayList<String> categoryList = new ArrayList <String>();
    private MainActivity mainActivity;

    public NewsSourceAPI(MainActivity mainActivity, String category_type)
    {
        Log.d(TAG,"have you come here------------"+category_type);
        if(category_type.equalsIgnoreCase("") || category_type.equals("All"))
        {
            this.mainActivity = mainActivity;
            Log.d(TAG,"api se call------");
            this.category = "";
            newsurl = "https://newsapi.org/v2/sources?language=en&country=us&category="+category+"&apiKey="+API;
        }
        else{
            this.mainActivity = mainActivity;
            this.category = category_type;
            newsurl = "https://newsapi.org/v2/sources?language=en&country=us&category="+category+"&apiKey="+API;
        }
    }

    @Override
    protected String doInBackground(String... strings) {
        builder = Uri.parse(newsurl).buildUpon();
        connectToUrl();
        if(!noDataFound)
        {
            parseData(sb1.toString());
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        for(int k=0; k<sourceList.size();k++)
        {
            String cat = sourceList.get(k).getSourceCategory();
            if(!categoryList.contains(cat))
            {
                categoryList.add(cat);
            }
        }
        mainActivity.sendResult(sourceList, categoryList);
    }

    public void connectToUrl(){
        String urlToUse = builder.build().toString();
        sb1 = new StringBuilder();
        try {
            URL url = new URL(urlToUse);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if(conn.getResponseCode() == HttpURLConnection.HTTP_NOT_FOUND)
            {
                noDataFound=true;
            }
            else {
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line=null;
                while ((line = reader.readLine()) != null) {
                    sb1.append(line).append('\n');
                }
                //isNoDataFound=false;

            }
        }
        catch(FileNotFoundException fe){
            Log.d(TAG, "FileNotFoundException ");
        }
        catch (Exception e) {
            //e.printStackTrace();
            Log.d(TAG, "Exception doInBackground: " + e.getMessage());
        }
    }

    private void parseData(String data)
    {
        try{
            JSONObject js = new JSONObject(data);
            JSONArray jsonArray =js.getJSONArray("sources");
            for(int i=0; i<jsonArray.length();i++)
            {
                JSONObject src = (JSONObject) jsonArray.get(i);
                Source s = new Source();
                s.setSourceCategory(src.getString("id"));
                s.setSourceName(src.getString("name"));
                s.setSourceCategory(src.getString("category"));
                s.setSourceUrl(src.getString("url"));
                sourceList.add(s);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
