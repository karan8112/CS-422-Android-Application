package news.iit.com.news;

import java.io.Serializable;

public class Article implements Serializable {
    String Author;
    String Title;
    String Description;
    String Imageurl;
    String PublishedAt;
    String addressurl;

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        Author = author;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getImageurl() {
        return Imageurl;
    }

    public void setImageurl(String imageurl) {
        Imageurl = imageurl;
    }

    public String getPublishedAt() {
        return PublishedAt;
    }

    public void setPublishedAt(String publishedAt) {
        PublishedAt = publishedAt;
    }

    public String getAddressurl() {
        return addressurl;
    }

    public void setAddressurl(String addressurl) {
        this.addressurl = addressurl;
    }


}
