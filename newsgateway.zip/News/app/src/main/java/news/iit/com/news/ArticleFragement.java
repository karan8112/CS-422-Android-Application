package news.iit.com.news;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class ArticleFragement extends Fragment {

    private static final String TAG = "ArticleFragement";
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    public static final String index_of_page = "index";
    public static  final String total_page = "total_page";
    public static final String data = "article_data";

    ImageView article_image;
    Article article;
    TextView article_title;
    TextView article_author;
    TextView article_date;
    TextView article_description;
    TextView article_count;
    Integer count_of_page;
    View v;




    public ArticleFragement() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static ArticleFragement newInstance(Article a, int index, int total) {
        ArticleFragement fragment = new ArticleFragement();
        Bundle args = new Bundle();
        args.putSerializable(data, a);
        args.putInt(index_of_page, index);
        args.putInt(total_page, total);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG,"return-------------");
        setRetainInstance(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        article  = (Article) getArguments().getSerializable(data);
        count_of_page = getArguments().getInt(index_of_page)+1;
        int total = getArguments().getInt(total_page);
        String lastLine = count_of_page+" of "+total;


        v = inflater.inflate(R.layout.fragment_article_fragement, container, false);
        article_title = (TextView)v.findViewById(R.id.HeadLine);
        article_date = (TextView) v.findViewById(R.id.Date);
        article_author = (TextView) v.findViewById(R.id.Author);
        article_description = (TextView) v.findViewById(R.id.Text);
        article_count = (TextView) v.findViewById(R.id.count);
        article_image = (ImageView) v.findViewById(R.id.imageView2);

        article_count.setText(lastLine);
        if(article.getTitle() != null){ article_title.setText(article.getTitle());
        }
        else{article_title.setText("");}

        if(article.getPublishedAt() !=null && !article.getPublishedAt().isEmpty()) {

            String sDate1 = article.getPublishedAt();

            Date date1 = null;
            String pubdate = "";
            try {
                if(sDate1 != null){

                    date1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(sDate1);}
                String pattern = "MMM dd, yyyy HH:mm";
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
                pubdate = simpleDateFormat.format(date1);
                article_date.setText(pubdate);
            } catch (ParseException e) {
                //e.printStackTrace();
            }
        }
        if(article.getAuthor()!=null) {article_author.setText(article.getAuthor());}
        else{article_author.setText("");}
        Log.d(TAG,"get description------------"+article.getDescription());

        if(article.getDescription() != null) {article_description.setText(article.getDescription());}
        else{article_description.setText("");}

        article_author.setMovementMethod(new ScrollingMovementMethod());

        if(article.getImageurl()!=null){loadRemoteImage(article.getImageurl());}

        article_title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(article.getAddressurl()));
                startActivity(intent);
            }
        });

        article_description.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(article.getAddressurl()));
                startActivity(intent);
            }
        });



        article_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(article.getAddressurl()));
                startActivity(intent);
            }
        });

        return v;
    }



    private  void loadRemoteImage(final String imageURL){

        if (imageURL != null) {
            Picasso picasso = new Picasso.Builder(getActivity()).listener(new Picasso.Listener() {
                @Override
                public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                    // Here we try https if the http image attempt failed
                    final String changedUrl = imageURL.replace("http:", "https:");
                    picasso.load(changedUrl)
                            .fit()
                            .centerCrop()
                            .error(R.drawable.ic_broken_image_black_24dp)
                            .placeholder(R.drawable.ic_insert_photo_black_24dp)
                            .into(article_image);
                }
            }).build();
            picasso.load(imageURL)
                    .fit()
                    .centerCrop()
                    .error(R.drawable.ic_broken_image_black_24dp)
                    .placeholder(R.drawable.ic_insert_photo_black_24dp)
                    .into(article_image);
        } else {
            Picasso.with(getActivity()).load(imageURL)
                    .fit()
                    .centerCrop()
                    .error(R.drawable.ic_broken_image_black_24dp)
                    .placeholder(R.drawable.ic_insert_photo_black_24dp)
                    .into(article_image);
        }
    }





}
