package news.iit.com.news;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class NewsArticleAPI extends AsyncTask<String, Void, String> {
    private  ArticleService mainActivity;
    private String source_name;
    private Uri.Builder builder;
    private static final String TAG = "NewsArticleAPI";
    private StringBuilder sb1;
    private boolean noDataFound=false;
    private String articleurl;
    private String API = "94a257111d92411896069c0bc292c8ff";
    private ArrayList<Article> article_list = new ArrayList <Article>();

    public NewsArticleAPI(ArticleService ma, String sourcename)
    {
        this.mainActivity = ma;
        source_name = sourcename;
    }

    @Override
    protected String doInBackground(String... strings) {
        Log.d(TAG,"yes i am here---------------");
        articleurl = "https://newsapi.org/v2/everything?sources="+source_name+"&language=en&pageSize=100&apiKey="+API;
        builder = Uri.parse(articleurl).buildUpon();
        connectToUrl();
        if(!noDataFound)
        {
            parseData(sb1.toString());
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Log.d(TAG,"yes sending back---------------");
        mainActivity.setArticle(article_list);
    }

    public void connectToUrl(){
        String urlToUse = builder.build().toString();
        sb1 = new StringBuilder();
        try {
            URL url = new URL(urlToUse);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if(conn.getResponseCode() == HttpURLConnection.HTTP_NOT_FOUND)
            {
                noDataFound=true;
            }
            else {
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line=null;
                while ((line = reader.readLine()) != null) {
                    sb1.append(line).append('\n');
                }
                //isNoDataFound=false;

            }
        }
        catch(FileNotFoundException fe){
            Log.d(TAG, "FileNotFoundException ");
        }
        catch (Exception e) {
            //e.printStackTrace();
            Log.d(TAG, "Exception doInBackground: " + e.getMessage());
        }
    }

    public void parseData(String data)
    {
        try{
                Log.d(TAG,"yes i am creating article objcet---------------"+data);
                JSONObject jObjMain = new JSONObject(data);
                JSONArray articles = jObjMain.getJSONArray("articles");
                for(int i=0;i<articles.length();i++){
                    JSONObject art = (JSONObject) articles.get(i);
                    Article artObj = new Article();
                    artObj.setAuthor(art.getString("author"));
                    artObj.setDescription(art.getString("description"));
                    artObj.setPublishedAt(art.getString("publishedAt"));
                    artObj.setTitle(art.getString("title"));
                    artObj.setImageurl(art.getString("urlToImage"));
                    artObj.setAddressurl(art.getString("url"));
                    article_list.add(artObj);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
