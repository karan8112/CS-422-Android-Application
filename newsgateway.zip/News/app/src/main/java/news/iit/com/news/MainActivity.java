package news.iit.com.news;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private List<Fragment> fragments;
    private DrawerLayout mDrawerLayout;
    private ListView sourcelistview;
    private ViewPager pager;
    private int source_pointer;
    private Context context;
    private boolean serviceRunning = false;
    private ActionBarDrawerToggle mDrawerToggle;
    private Menu drawer_menu;
    private ArrayList<String> category_list = new ArrayList<>();
    private int [] allColors;
    android.content.res.Resources res;
    private ArrayAdapter adapter;
    private ArrayList<android.text.SpannableString> srcList = new ArrayList<>();
    private HashMap<String, Integer> menu_color = new HashMap<>();
    private String sourceselected;
    private MyPageAdapter pageAdapter;
    static final String Get_Source_Data = "Get_Source_Data";
    static final String Get_Article_Data = "Get_Article_Data";
    private ArrayList<Source> sourceArrayList = new ArrayList <Source>();
    private ArrayList<Article> articles_list = new ArrayList <Article>();
    private HashMap<String, Source> source_cate = new HashMap<>();
    private boolean stateFlag;
    private int currentSourcePointer;

    private ServiceReceiver articleReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("News Gateway");
        if(!serviceRunning &&  savedInstanceState == null) {
            Intent intent = new Intent(MainActivity.this, ArticleService.class);
            startService(intent);
            serviceRunning = true;
        }

        mDrawerLayout = (DrawerLayout) findViewById(R.id.layout_drawer);
        sourcelistview = (ListView) findViewById(R.id.left_drawer);

        sourcelistview.setOnItemClickListener(
                new ListView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        pager.setBackgroundResource(0);
                        source_pointer = position;
                        sourceselection(position);
                        Log.d(TAG,"ur doing something---------------");
                    }
                }
        );

        //allColors = context.getResources().getStringArray(R.array.rainbow);
        res = getResources();
        allColors = res.getIntArray(R.array.rainbow);
        mDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.drawer_open,R.string.drawer_close);


        articleReceiver = new ServiceReceiver();
        IntentFilter filter1 = new IntentFilter(MainActivity.Get_Article_Data);
        registerReceiver(articleReceiver, filter1);

        adapter = new ArrayAdapter<>(this, R.layout.element_list, srcList);
        sourcelistview.setAdapter(adapter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        fragments = new ArrayList<>();

        pageAdapter = new MyPageAdapter(getSupportFragmentManager());
        pager = findViewById(R.id.pager);
        pager.setAdapter(pageAdapter);

        Log.d(TAG,"main se call------");

        if (source_cate.isEmpty() && savedInstanceState == null )
            new NewsSourceAPI(this, "").execute();

    }




    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggls
        mDrawerToggle.onConfigurationChanged(newConfig);
        setTitle("News Gateway");
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.category_menu, menu);
        Log.d(TAG,"main se call------2");
        drawer_menu = menu;
        if(stateFlag){
            Log.d(TAG,"do u having good time-----------");
            drawer_menu.add("All");
            for (String s : category_list)
                drawer_menu.add(s);
            setColors();
        }
        return true;
    }

    public void sendResult(ArrayList<Source> sourcelist, ArrayList<String> categorylist)
    {
        sourceArrayList.clear();
        srcList.clear();
        source_cate.clear();


        sourceArrayList.addAll(sourcelist);
        if(!drawer_menu.hasVisibleItems())
        {
            category_list.clear();
            category_list =categorylist;
            drawer_menu.add("All");
            //Collections.sort(categorylist);
            for (String s : categorylist)
                drawer_menu.add(s);
            setColors();
        }

        srcList.clear();
        for(int k=0; k<sourcelist.size(); k++)
        {
            String key = sourcelist.get(k).getSourceCategory();
            Integer color = menu_color.get(key);
            SpannableString spanString = new SpannableString(sourcelist.get(k).getSourceName());
            spanString.setSpan(new ForegroundColorSpan(color), 0,     spanString.length(), 0);
            srcList.add(spanString);
            source_cate.put(sourcelist.get(k).getSourceName(), (Source)sourcelist.get(k));

        }


        adapter.notifyDataSetChanged();
    }

    public void setColors(){
        menu_color.clear();
        for(int i = 0; i < drawer_menu.size(); i++) {
            MenuItem item = drawer_menu.getItem(i);
            SpannableString spanString = new SpannableString(drawer_menu.getItem(i).getTitle().toString());
            spanString.setSpan(new ForegroundColorSpan(allColors[i]), 0,     spanString.length(), 0); //fix the color to white
            item.setTitle(spanString);
            menu_color.put(drawer_menu.getItem(i).getTitle().toString(),allColors[i]);
        }
    }

    public void sourceselection(int pos)
    {
        Log.d(TAG,"yes i am doing something---------------");
        sourceselected = srcList.get(pos).toString();
        Intent intent = new Intent(MainActivity.Get_Source_Data);
        intent.putExtra("Source_Name",sourceselected);
        sendBroadcast(intent);
        Log.d(TAG,"ru going there---------------");
        mDrawerLayout.closeDrawer(sourcelistview);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.d(TAG,"main se call------3");
        if(mDrawerToggle.onOptionsItemSelected(item))
        {
            return true;
        }
        new NewsSourceAPI(this, item.getTitle().toString()).execute();
        mDrawerLayout.openDrawer(sourcelistview);
        return super.onOptionsItemSelected(item);
    }




    private class MyPageAdapter extends FragmentPagerAdapter{
        private long baseId = 0;

        public MyPageAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Override
        public long getItemId(int position) {
            // give an ID different from position when position has been changed
            return baseId + position;
        }

        public void notifyChangeInPosition(int n) {
            // shift the ID returned by getItemId outside the range of all previous fragments
            baseId += getCount() + n;
        }

    }





    class ServiceReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {

                case Get_Article_Data:
                    Log.d(TAG,"bosst up--------------");
                    ArrayList<Article> artList;
                    if (intent.hasExtra("display_article")) {
                        artList = (ArrayList <Article>) intent.getSerializableExtra("display_article");
                        setFragement(artList);
                    }
                    break;
            }
        }
    }





    private void setFragement(ArrayList<Article> articles) {
        Log.d(TAG,"setfragement--------------"+articles.size());
        setTitle(sourceselected);
        for (int i = 0; i < pageAdapter.getCount(); i++)
            pageAdapter.notifyChangeInPosition(i);

        fragments.clear();
        for (int i = 0; i < articles.size(); i++) {
            Article a = articles.get(i);
            Log.d(TAG,"article fragement call---------------");
            fragments.add(ArticleFragement.newInstance(articles.get(i), i, articles.size()));
        }

        pageAdapter.notifyDataSetChanged();
        pager.setCurrentItem(0);
        articles_list = articles;
    }


    @Override
    protected void onDestroy() {
        unregisterReceiver(articleReceiver);
        Intent intent = new Intent(MainActivity.this, ServiceReceiver.class);
        stopService(intent);
        super.onDestroy();
    }




    @Override
    protected void onSaveInstanceState(Bundle outState) {
        Restore_Layout layoutRestore = new Restore_Layout();
        layoutRestore.setCategories(category_list);
        layoutRestore.setSourceList(sourceArrayList);
        layoutRestore.setCurrentArticle(pager.getCurrentItem());
        layoutRestore.setCurrentSource(source_pointer);
        layoutRestore.setArticleList(articles_list);
        layoutRestore.setMenu_color(menu_color);
        layoutRestore.setSource_name(sourceselected);
        //layoutRestore.setDrawer_menu(drawer_menu);
        outState.putSerializable("state", layoutRestore);
        super.onSaveInstanceState(outState);
    }


    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        //setContentView(R.layout.activity_main);
        Restore_Layout layoutRestore1 = (Restore_Layout) savedInstanceState.getSerializable("state");
        setTitle("News Gateway");
        stateFlag = true;
        articles_list = layoutRestore1.getArticleList();
        category_list = layoutRestore1.getCategories();
        sourceArrayList = layoutRestore1.getSourceList();
        menu_color = layoutRestore1.getMenu_color();
        sourceselected = layoutRestore1.getSource_name();
        /*drawer_menu = layoutRestore1.getDrawer_menu();
        if(!drawer_menu.hasVisibleItems())
        {
            category_list.clear();
            category_list =category_list;
            drawer_menu.add("All");
            //Collections.sort(categorylist);
            for (String s : category_list)
                drawer_menu.add(s);
            setColors();
        }*/




        for(int i=0;i<sourceArrayList.size();i++){
            String key = sourceArrayList.get(i).getSourceCategory();
            Integer color = menu_color.get(key);
            SpannableString spanString = new SpannableString(sourceArrayList.get(i).getSourceName());
            spanString.setSpan(new ForegroundColorSpan(color), 0,     spanString.length(), 0);
            srcList.add(spanString);
            source_cate.put(sourceArrayList.get(i).getSourceName(), (Source)sourceArrayList.get(i));
        }
        sourcelistview.clearChoices();
        adapter.notifyDataSetChanged();
        sourcelistview.setOnItemClickListener(

                new ListView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        pager.setBackgroundResource(0);
                        currentSourcePointer = position;
                        sourceselection(position);

                    }
                }
        );
        if(articles_list.size()!=0)
        {
            pager.setBackgroundResource(0);
            setTitle(sourceselected);
            for (int i = 0; i < pageAdapter.getCount(); i++)
                pageAdapter.notifyChangeInPosition(i);

            fragments.clear();

            for (int i = 0; i < articles_list.size(); i++) {
                Article gsf = articles_list.get(i);
                Log.d(TAG,"set na stupid---------");
                fragments.add(ArticleFragement.newInstance(articles_list.get(i), i, articles_list.size()));
            }

            pageAdapter.notifyDataSetChanged();
            pager.setCurrentItem(layoutRestore1.getCurrentArticle());
        }
        //pager.setBackgroundResource(0);
        //setFragement(articles_list);
        //pager.setCurrentItem(layoutRestore1.getCurrentArticle());
    }
}
