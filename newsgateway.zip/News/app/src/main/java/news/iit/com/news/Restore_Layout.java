package news.iit.com.news;

import android.view.Menu;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;


public class Restore_Layout implements Serializable {
        private ArrayList<Source> sourceList = new ArrayList<Source>();
        private ArrayList<Article> articleList = new ArrayList <Article>();
        private ArrayList<String> categories = new ArrayList <String>();

    public String getSource_name() {
        return source_name;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    private String source_name;

    public Menu getDrawer_menu() {
        return drawer_menu;
    }

    public void setDrawer_menu(Menu drawer_menu) {
        this.drawer_menu = drawer_menu;
    }

    private Menu drawer_menu;

    public HashMap<String, Integer> getMenu_color() {
        return menu_color;
    }

    public void setMenu_color(HashMap<String, Integer> menu_color) {
        this.menu_color = menu_color;
    }

    private HashMap<String, Integer> menu_color = new HashMap<>();
        private int currentSource;
        private int currentArticle;

        public ArrayList <Source> getSourceList() {
            return sourceList;
        }

        public void setSourceList(ArrayList <Source> sourceList) {
            this.sourceList = sourceList;
        }

        public ArrayList <Article> getArticleList() {
            return articleList;
        }

        public void setArticleList(ArrayList <Article> articleList) {
            this.articleList = articleList;
        }

        public ArrayList <String> getCategories() {
            return categories;
        }

        public void setCategories(ArrayList <String> categories) {
            this.categories = categories;
        }

        public int getCurrentSource() {
            return currentSource;
        }

        public void setCurrentSource(int currentSource) {
            this.currentSource = currentSource;
        }

        public int getCurrentArticle() {
            return currentArticle;
        }

        public void setCurrentArticle(int currentArticle) {
            this.currentArticle = currentArticle;
        }
    }

