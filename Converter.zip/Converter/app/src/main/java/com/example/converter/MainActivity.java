package com.example.converter;

import android.os.Bundle;
import java.text.DecimalFormat;
import android.support.design.widget.FloatingActionButton;
import android.text.method.ScrollingMovementMethod;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private boolean check;
    private TextView tv, tv1, output;
    private EditText userInput;
    private RadioButton r3, r4;
    private TextView scrollingText;
    StringBuilder sb = new StringBuilder();
    static String s = "", sa = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


        tv = (TextView) findViewById(R.id.textView2);
        tv1 = (TextView) findViewById(R.id.textView4);
        userInput = findViewById(R.id.editText);
        output = findViewById(R.id.textView5);
        r3 = (RadioButton) findViewById(R.id.radioButton3);
        r4 = (RadioButton) findViewById(R.id.radioButton4);
        scrollingText = (TextView) findViewById(R.id.textView7);
        scrollingText.setMovementMethod(new ScrollingMovementMethod());

        if (savedInstanceState != null)
        {
            sa = savedInstanceState.getString( "HISTORY");
        }

    }



    public void onRadioButtonClicked(View view) {
        check = ((RadioButton) view).isChecked();
        switch(view.getId())
        {
            case R.id.radioButton3:
                if (check)
                    Log.d(TAG, "onRadioButtonClicked: This is in onRadioButtonClicked3!");
                    tv.setText("Fahrenheit Degrees:");
                    tv1.setText("Celsius Degrees:");
                break;
            case R.id.radioButton4:
                if(check)
                    Log.d(TAG, "onRadioButtonClicked: This is in onRadioButtonClicked4!");
                    tv.setText("Celsius Degrees:");
                    tv1.setText("Fahrenheit Degrees:");
                break;

        }

    }

    public void buttonClicked(View v)
    {
        DecimalFormat df = new DecimalFormat("#.##");
        String text = userInput.getText().toString().trim();
        double val = 0.0;
        double ans = 0.0;
        String text1;
        Log.d(TAG, "buttonClicked: This is in buttonClicked!");
        if(r3.isChecked())
        {
            if(text.trim().isEmpty())
            {
                Toast.makeText(getApplicationContext(), "Please Enter Temperature in Farenheit", Toast.LENGTH_SHORT).show();
            }
            else{
                val = Double.parseDouble(text);
                ans = (val - 32.0)/1.8;
                ans = (double)Math.round(ans * 10)/(double)10;
                Log.d(TAG, "buttonClicked: This is in buttonClicked!");
                text1 = Double.toString(ans);
                if(!text1.trim().isEmpty())
                    output.setText(text1);
                if(r3.isChecked())
                {
                    s = text + " F ==> " + text1 + " C\n" + s;
                    //sb.insert(0, text + " F ==> " + text1 + " C\n" );
                    scrollingText.setText(s);
                }
            }


        }
        if(r4.isChecked())
        {
            if(text.trim().isEmpty())
            {
                Toast.makeText(getApplicationContext(), "Please Enter Temperature in Celcius", Toast.LENGTH_SHORT).show();
            }
            else{
                val = Double.parseDouble(text);
                ans = Math.ceil((val * 1.8) + 32.0);
                ans = (double)Math.round(ans * 10)/(double)10;
                text1 = Double.toString(ans);
                if(!text1.trim().isEmpty())
                    output.setText(text1);
                if(r4.isChecked())
                {
                    s = text + " C ==> " + text1 + " F\n" + s;
                    //sb.insert(0, text + " C ==> " + text1 + " F\n" );
                    scrollingText.setText(s);
                }
            }


        }

    }

    public void clearButton(View v1)
    {
        //sb.setLength(0);
        s = "";
        scrollingText.setText("");
    }

    protected void onSaveInstanceState(Bundle os) {

        os.putString("userInput", userInput.getText().toString());
        os.putString("output", output.getText().toString());
        os.putString("history", scrollingText.getText().toString());
        os.putString("r3",r3.getText().toString()) ;
        os.putString("r4",r4.getText().toString()) ;
        os.putString("tv",tv.getText().toString()) ;
        os.putString("tv1",tv1.getText().toString()) ;
        super.onSaveInstanceState(os);
    }

    @Override
    protected void onRestoreInstanceState(Bundle si) {

        super.onRestoreInstanceState(si);

        userInput.setText(si.getString("userInput"));
        output.setText(si.getString("output"));
        scrollingText.setText(si.getString("history"));
        r3.setText(si.getString("r3"));
        r4.setText(si.getString("r4"));
        tv.setText(si.getString("tv"));
        tv1.setText(si.getString("tv1"));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
